#include <iostream>
#include <stdlib.h>
#include <cmath>

using namespace std;

/*
	Calcular potencia:
	Entradas: (Tipo Entero) la base y el exponente.
	Salida: (Tipo Entero) Retorna la base elevada al exponente.
*/

int potenciatotal  (int base , int exponente){

  int p = 1;

  for (int i = 1; i <= exponente; i++){
    p = p * base;
  }

  return p;
}

/*
	Calcular potencia:
	Entradas: Dos listas, una grande, y una pequeña
	Salida: verificamos si la lista se encuentra en la lista grande justo en
   sus posiciones.
*/

int emparejamiento_cadenas (char v1[],char v2[]) {


  int c,i,k,j = 0;
  int sw = 0;

  for ( i = 0; i < 15; i++) {

    c = i;

    for (k = 0; k < 4; k++) {

      if (v2[k] == v1[c]) {
        j++;
      }

    c++;

    }

    if (j == 5) {

      sw = 1;
      return i;
    }
  }

  if (sw == 0) {
    //std::cout << "NO EMPAREJADOS" << '\n';
    return (-1);
  }

}

/*
	Calcular potencia:
	Entradas:  cadena ya predeterminada
	Salida: ordena la lista de numeros de mi cadena.
*/

void ordenamiento_burbuja (int v[]){

  int i,j,aux;

  for ( i = 0; i < 5; i++) {
    for (j = i+1 ; j < 5 ; j++) {
      if (v[j] < v[i]) {
        aux = v[i];
        v[i] = v[j];
        v[j] = aux;
      }
    }
  }

  for ( i = 0; i < 5; i++) {
    std::cout << " " << v[i];
  }

}

/*
	Busqueda secuencial:
	Entradas: (Tipo Entero) cadena y numero a buscar.
	Salida: Sale por pantalla si el numero se encuentra en nuestra lista o no.
*/

int busqueda_secuencial (int v[] , int x ){

  int k;
  int sw = 0;


  for (k = 0 ; k < 5 ; k++) {

    if (x == v[k]) {
      sw = 1;
      cout << " " << k << endl;
      return k;
    }

  }

  if (sw == 0){

    cout << "No se encuentra el numero aqui." << '\n';
    return (-1);
  }

}
