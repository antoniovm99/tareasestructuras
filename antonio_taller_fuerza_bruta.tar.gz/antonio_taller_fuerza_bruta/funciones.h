int potenciatotal  (int base , int exponente);
int emparejamiento_cadenas (char v1[],char v2[]);
void ordenamiento_burbuja (int v[]);
int busqueda_secuencial (int v[] , int x );
