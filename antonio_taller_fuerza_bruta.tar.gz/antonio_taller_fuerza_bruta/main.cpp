/*

Taller de algoritmo fuerza bruta

descripcion: librerias de algoritmos de fuerza bruta.
creado por: Antonio Isaac varona Muñoz.

*/

#include <iostream>
#include <stdlib.h>
#include "funciones.h"

using namespace std;

int main() {

  /*

  Descripcion: es la funcion principal que hace el llamado a las demas funciones
  puestas en funciones.cpp , preguntaremos al usuario que opcion desea, y
  se de desarrollara lo requerido.

  */

  int opcion, resultado;

  int v[] ={9,8,7,6,5};
  char v1[] = {'h','o','l','a','c','o','m','o','e','s','t','a','s','h','o','y'};
  char v2[] = {'p','x','s','a'};
  int op;

  std::cout << "***** FUERZA BRUTA***** " << '\n';
  std::cout << "" << '\n';
  std::cout << "1) Calcular potencia." << '\n';
  std::cout << "2) Busqueda secuencial." << '\n';
  std::cout << "3) Ordenamiento Burbuja." << '\n';
  std::cout << "4) Emparejamiento de cadenas." << '\n';
  std::cout << "5) Exit. " << '\n';

  std::cout << "Que opcion desea: " << '\n';
  std::cin >> opcion;

  switch (opcion) {

    case 0:

      return 0; break;

    case 1:

      int base, exponente;

      std::cout << "digite la base: " << '\n';
      std::cin >> base;
      std::cout << "digite el exponente: " << '\n';
      std::cin >> exponente;
      resultado = potenciatotal  ( base , exponente) ;
      cout << "El resultado es:" << resultado << endl;

      break;


    case 2:

      int x;
      std::cout << "Escriba numero de un digito a buscar en cadena: " << '\n';
      std::cin >> x;
      busqueda_secuencial(v,x);

      break;

    case 3:

      ordenamiento_burbuja(v);

      break;

    case 4:

      op = emparejamiento_cadenas(v1,v2);
      if (op == -1) {
        std::cout << "NO EMPAREJADOS" << '\n';
      }
      else {
        std::cout << "EMPAREJADOS" << '\n';
      }

      break;

      case 5:

        return 0; break;


      default:

        std::cout << "SELECCIONASTE FUERAS DE LAS OPCIONES." << '\n';
        break;

  }

  return 0;
}
