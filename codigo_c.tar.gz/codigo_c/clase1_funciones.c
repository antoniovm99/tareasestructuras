#include <stdio.h>
#include <stdlib.h>

int casa = 10; // podemos declarar esta variable como global, y la podemos utilizar en cualquier funcion.
int multi(int a, int b);

int main() {
  int a,b,c;
  a = 10;
  b = 5;

  c = multi(a,b);
  printf("el valor a multiplicar %d por  %d es %d \n",a,b,c );
  return 0;
}

int multi(int a, int b){

  int c = a*b;
  return c;
}
