#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <time.h>
#include <unistd.h>
#include <cstdlib>
#include "Jugador.h"
#include "Tablero.h"

using namespace std;


int main()
{
	Tablero tbl;
    Jugador jugadorreal("",0, tbl);
    Jugador jugadormaquina("Maquina",0, tbl);
    jugadorreal.pedir_nombre();
		string nombrereal = jugadorreal.getnombre();
		string nombremaquina = jugadormaquina.getnombre();
    system("clear");
    tbl.imprimir_nombre_juego();
    jugadorreal.imprimir_datos();
    jugadormaquina.imprimir_datos();
		tbl.imprimir_matriz();
    //int numero = 1 + rand() % (3 - 0);
    //cout << numero;
		int numero = 1;
    char letra;
    char letra2;
    if (numero == 1){
        int ganador = 1;
        while(ganador == 1){
						do {
            	letra = jugadorreal.obtenerletra();
							system("clear");
							tbl.imprimir_matriz();
						}while(tbl.cambiarSimbolos(letra, 'X')!=true);
						system("clear");
						tbl.imprimir_matriz ();
						int w = tbl.verificarTodos();
						if(w==1){
							//tbl.imprimir_matriz();
							tbl.ganador(nombrereal);
							ganador = 2;
							break;
						}
						system("clear");
						tbl.imprimir_matriz();
						//
						do {
            	letra2 = jugadorreal.obtenerletramaquina();
							system("clear");
							tbl.imprimir_matriz();
						}while(tbl.cambiarSimbolos(letra2, 'O')!=true);
						system("clear");
						tbl.imprimir_matriz ();
						int z = tbl.verificarTodos();
						if(z == 1){
							//tbl.imprimir_matriz();
							tbl.ganador(nombremaquina);
							ganador = 2;
							break;
						}
						system("clear");
						tbl.imprimir_matriz();
						ganador = 1;

        }

    if (numero == 2){
        ganador = 1;
        while(ganador == 1){
					do {
						letra2 = jugadorreal.obtenerletramaquina();
						system("clear");
						tbl.imprimir_matriz();
					}while(tbl.cambiarSimbolos(letra2, 'O')!=true);
					system("clear");
					tbl.imprimir_matriz ();
					int z = tbl.verificarTodos();
					if(z == 1){
						//tbl.imprimir_matriz();
						tbl.ganador(nombremaquina);
						ganador = 2;
						break;
					}
					system("clear");
					tbl.imprimir_matriz();

					do {
          	letra = jugadorreal.obtenerletra();
						system("clear");
						tbl.imprimir_matriz();
					}while(tbl.cambiarSimbolos(letra, 'X')!=true);
					system("clear");
					tbl.imprimir_matriz ();
					int w = tbl.verificarTodos();
					if(w==1){
						//tbl.imprimir_matriz();
						tbl.ganador(nombrereal);
						ganador = 2;
						break;
					}
					system("clear");
					tbl.imprimir_matriz();
					ganador = 1;

        }
    }


	return 0;
}
}
