#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <time.h>
#include <unistd.h>
#include <cstdlib>
#include "Jugador.h"
#include "Tablero.h"

using namespace std;


Jugador :: Jugador(string _nombre,int _puntos, Tablero &tbl1){
    nombre = _nombre;
    puntos = _puntos;
		tbl = tbl1;
}

void Jugador :: pedir_nombre(){
    cout << "Digite su Nombre: " << endl;
    cin >> nombre;
}

string Jugador :: getnombre(){
	return nombre;
}

void Jugador :: imprimir_datos(){
    cout <<"Jugador Activo: " << nombre << "       " << "Puntos: "<< puntos << endl;
    cout << "\n";
}

char Jugador :: obtenerletra(){
    cout << "Que Casilla Escoge: " << endl;
    cin >> letra;
		return letra;
	}

char Jugador :: obtenerletramaquina(){
    int numero = 1 + rand() % (9 - 0);
    return listaletras[numero];
}
