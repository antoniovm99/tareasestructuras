#ifndef __JUGADOR_H__
#define __JUGADOR_H__
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <time.h>
#include <unistd.h>
#include <cstdlib>
#include "Tablero.h"


using namespace std;

class Jugador{
private:
    string nombre;
    int puntos;
    char letra;
    char listaletras[9]={'a','b','c','d','e','f','g','h','i'};
		Tablero tbl;

public:
    Jugador(string,int, Tablero&);
    void pedir_nombre();
		string getnombre();
    void imprimir_datos();
    char obtenerletra();
    char obtenerletramaquina();
};

#endif
