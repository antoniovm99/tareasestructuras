#ifndef __TABLERO_H__
#define __TABLERO_H__
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <time.h>
#include <unistd.h>
#include <cstdlib>
#include "Jugador.h"

using namespace std;

class Tablero{
public:
	char matriz[3][3]={
					{'a','b','c'},
					{'d','e','f'},
					{'g','h','i'}
                };
    char matrizopciones[3][3]={
					   {'-','-','-'},
					   {'-','-','-'},
					   {'-','-','-'}
                    };
    string nombre_juego;
public:
	Tablero();
	void imprimir_matriz();
  void imprimir_nombre_juego();
	bool cambiarSimbolos (char letra, char simbolo);
	void ganador(string winner);
	bool verificarHorizontal();
	bool verificarVertical();
	bool verificarDiagonalDerecha();
	bool  verificarDiagonalizquierda();
	int verificarTodos();
};

#endif
