#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <time.h>
#include <unistd.h>
#include <cstdlib>
#include "Tablero.h"
#include "Jugador.h"

using namespace std;

Tablero::Tablero(){}

void Tablero::imprimir_matriz(){
            for (int i=0; i<3; i++){
                printf("           ");
                for (int p=0; p<3; p++){
                    printf("| %c (%c) ", matrizopciones[i][p],matriz[i][p]);
                }
                printf("| \n");
                printf("                \n");
            }
        }

void Tablero :: imprimir_nombre_juego(){
    cout << "    |+|+|+|+| JUEGO TRIQUI |+|+|+|+|" << endl;
    cout << "" << endl;
}

bool Tablero::cambiarSimbolos (char letra, char simbolo) {
    for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
						if(matriz[i][j] == letra){
							if (matrizopciones[i][j] == 'X' || matrizopciones[i][j] == 'O') {
								return false;
							}else {
									matrizopciones[i][j] = simbolo;
									return true;
							}
					}
				}
    }
		return false;
}

void Tablero :: ganador(string winner){
	cout << "El Ganador fue: " << winner << endl;
}


bool Tablero :: verificarHorizontal(){
 	for (int  i = 0; i < 3; i++) {
		 if ((matrizopciones[i][0] == matrizopciones[i][1]) &&
				 (matrizopciones[i][0] == matrizopciones[i][2]) && matrizopciones[i][0]!='-') {
					return true;
		}
	}
 	return false;
}

bool Tablero :: verificarVertical(){
 	for (int  i = 0; i < 3; i++) {
		 if ((matrizopciones[0][i] == matrizopciones[1][i]) &&
				 (matrizopciones[0][i] == matrizopciones[2][i]) && matrizopciones[0][i]!='-') {
					return true;
		}
	}
 	return false;
}

bool Tablero :: verificarDiagonalDerecha(){
 	for (int  i = 0; i < 3; i++) {
		 if ((matrizopciones[0][2] == matrizopciones[1][1]) &&
				 (matrizopciones[0][2] == matrizopciones[2][0]) && matrizopciones[0][2]!='-') {
					return true;
		}
	}
 	return false;
}

bool Tablero :: verificarDiagonalizquierda(){
 	for (int  i = 0; i < 3; i++) {
		 if ((matrizopciones[0][0] == matrizopciones[1][1]) &&
				 (matrizopciones[0][0] == matrizopciones[2][2]) && matrizopciones[0][0]!='-') {
					return true;
		}
	}
 	return false;
}

int  Tablero :: verificarTodos(){
	if(verificarHorizontal() == true || verificarVertical() == true || verificarDiagonalizquierda()  == true ||
			verificarDiagonalDerecha() == true){
				return 1;
			}
	return 2;
}
