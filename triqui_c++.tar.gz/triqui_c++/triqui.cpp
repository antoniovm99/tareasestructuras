#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <time.h>
#include <unistd.h>
#include <cstdlib>

using namespace std;

class Tablero{
public:
	char matriz[3][3]={
					{'a','b','c'},
					{'d','e','f'},
					{'g','h','i'}
                };
    char matrizopciones[3][3]={
					   {'-','-','-'},
					   {'-','-','-'},
					   {'-','-','-'}
                    };
    string nombre_juego;
public:
	Tablero();
	void imprimir_matriz();
  void imprimir_nombre_juego();
	bool cambiarSimbolos (char letra, char simbolo);
	void ganador(string winner);
	bool verificarHorizontal();
	bool verificarVertical();
	bool verificarDiagonalDerecha();
	bool  verificarDiagonalizquierda();
	int verificarTodos();
};


Tablero::Tablero(){}

void Tablero::imprimir_matriz(){
            for (int i=0; i<3; i++){
                printf("           ");
                for (int p=0; p<3; p++){
                    printf("| %c (%c) ", matrizopciones[i][p],matriz[i][p]);
                }
                printf("| \n");
                printf("                \n");
            }
        }

void Tablero :: imprimir_nombre_juego(){
    cout << "    |+|+|+|+| JUEGO TRIQUI |+|+|+|+|" << endl;
    cout << "" << endl;
}

bool Tablero::cambiarSimbolos (char letra, char simbolo) {
    for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
						if(matriz[i][j] == letra){
							if (matrizopciones[i][j] == 'X' || matrizopciones[i][j] == 'O') {
								return false;
							}else {
									matrizopciones[i][j] = simbolo;
									return true;
							}
					}
				}
    }
		return false;
}

void Tablero :: ganador(string winner){
	cout << "El Ganador fue: " << winner << endl;
}


bool Tablero :: verificarHorizontal(){
 	for (int  i = 0; i < 3; i++) {
		 if ((matrizopciones[i][0] == matrizopciones[i][1]) &&
				 (matrizopciones[i][0] == matrizopciones[i][2]) && matrizopciones[i][0]!='-') {
					return true;
		}
	}
 	return false;
}

bool Tablero :: verificarVertical(){
 	for (int  i = 0; i < 3; i++) {
		 if ((matrizopciones[0][i] == matrizopciones[1][i]) &&
				 (matrizopciones[0][i] == matrizopciones[2][i]) && matrizopciones[0][i]!='-') {
					return true;
		}
	}
 	return false;
}

bool Tablero :: verificarDiagonalDerecha(){
 	for (int  i = 0; i < 3; i++) {
		 if ((matrizopciones[0][2] == matrizopciones[1][1]) &&
				 (matrizopciones[0][2] == matrizopciones[2][0]) && matrizopciones[0][2]!='-') {
					return true;
		}
	}
 	return false;
}

bool Tablero :: verificarDiagonalizquierda(){
 	for (int  i = 0; i < 3; i++) {
		 if ((matrizopciones[0][0] == matrizopciones[1][1]) &&
				 (matrizopciones[0][0] == matrizopciones[2][2]) && matrizopciones[0][0]!='-') {
					return true;
		}
	}
 	return false;
}

int  Tablero :: verificarTodos(){
	if(verificarHorizontal() == true || verificarVertical() == true || verificarDiagonalizquierda()  == true ||
			verificarDiagonalDerecha() == true){
				return 1;
			}
	return 2;
}


class Jugador{
private:
    string nombre;
    int puntos;
    char letra;
    char listaletras[9]={'a','b','c','d','e','f','g','h','i'};
		Tablero tbl;

public:
    Jugador(string,int, Tablero&);
    void pedir_nombre();
		string getnombre();
    void imprimir_datos();
    char obtenerletra();
    char obtenerletramaquina();
};

Jugador :: Jugador(string _nombre,int _puntos, Tablero &tbl1){
    nombre = _nombre;
    puntos = _puntos;
		tbl = tbl1;
}

void Jugador :: pedir_nombre(){
    cout << "Digite su Nombre: " << endl;
    cin >> nombre;
}

string Jugador :: getnombre(){
	return nombre;
}

void Jugador :: imprimir_datos(){
    cout <<"Jugador Activo: " << nombre << "       " << "Puntos: "<< puntos << endl;
    cout << "\n";
}

char Jugador :: obtenerletra(){
    cout << "Que Casilla Escoge: " << endl;
    cin >> letra;
		return letra;
	}

char Jugador :: obtenerletramaquina(){
    int numero = 1 + rand() % (9 - 0);
    return listaletras[numero];
}

int main()
{
	Tablero tbl;
    Jugador jugadorreal("",0, tbl);
    Jugador jugadormaquina("Maquina",0, tbl);
    jugadorreal.pedir_nombre();
		string nombrereal = jugadorreal.getnombre();
		string nombremaquina = jugadormaquina.getnombre();
    system("clear");
    tbl.imprimir_nombre_juego();
    jugadorreal.imprimir_datos();
    jugadormaquina.imprimir_datos();
		tbl.imprimir_matriz();
    //int numero = 1 + rand() % (3 - 0);
    //cout << numero;
		int numero = 1;
    char letra;
    char letra2;
    if (numero == 1){
        int ganador = 1;
        while(ganador == 1){
						do {
            	letra = jugadorreal.obtenerletra();
							system("clear");
							tbl.imprimir_matriz();
						}while(tbl.cambiarSimbolos(letra, 'X')!=true);
						system("clear");
						tbl.imprimir_matriz ();
						int w = tbl.verificarTodos();
						if(w==1){
							//tbl.imprimir_matriz();
							tbl.ganador(nombrereal);
							ganador = 2;
							break;
						}
						system("clear");
						tbl.imprimir_matriz();
						//
						do {
            	letra2 = jugadorreal.obtenerletramaquina();
							system("clear");
							tbl.imprimir_matriz();
						}while(tbl.cambiarSimbolos(letra2, 'O')!=true);
						system("clear");
						tbl.imprimir_matriz ();
						int z = tbl.verificarTodos();
						if(z == 1){
							//tbl.imprimir_matriz();
							tbl.ganador(nombremaquina);
							ganador = 2;
							break;
						}
						system("clear");
						tbl.imprimir_matriz();
						ganador = 1;

        }

    if (numero == 2){
        ganador = 1;
        while(ganador == 1){
					do {
						letra2 = jugadorreal.obtenerletramaquina();
						system("clear");
						tbl.imprimir_matriz();
					}while(tbl.cambiarSimbolos(letra2, 'O')!=true);
					system("clear");
					tbl.imprimir_matriz ();
					int z = tbl.verificarTodos();
					if(z == 1){
						//tbl.imprimir_matriz();
						tbl.ganador(nombremaquina);
						ganador = 2;
						break;
					}
					system("clear");
					tbl.imprimir_matriz();

					do {
          	letra = jugadorreal.obtenerletra();
						system("clear");
						tbl.imprimir_matriz();
					}while(tbl.cambiarSimbolos(letra, 'X')!=true);
					system("clear");
					tbl.imprimir_matriz ();
					int w = tbl.verificarTodos();
					if(w==1){
						//tbl.imprimir_matriz();
						tbl.ganador(nombrereal);
						ganador = 2;
						break;
					}
					system("clear");
					tbl.imprimir_matriz();
					ganador = 1;

        }
    }


	return 0;
}
}
