#include"lista.cpp"
#include<iostream>
using namespace std;

int main(){
	int b;
	lista<char> enteros;
	enteros.iniciar();
	enteros.insertar_lista('a');
	enteros.insertar_lista('g');
	enteros.insertar_lista('t');
	enteros.insertar_lista('y');
	enteros.mostrar();
	enteros.insertar_lista_posicion('u', 3);
	enteros.mostrar();
	for(int i = 0; i < enteros.longitud_lista(); i++){
		enteros.eliminar();
	}
}