#ifndef __NODO_H
#define __NODO_H
#include <stdio.h>

struct Nodo{
	int dato;
	Nodo *siguiente;
};
#endif