#include "gridsizer.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

GridSizer::GridSizer(const wxString& title)
       : wxFrame(NULL, -1, title, wxPoint(-1, -1), wxSize(270, 220))
{
  sizer = new wxBoxSizer(wxVERTICAL);

  display = new wxTextCtrl(this, -1, wxT(""), wxPoint(-1, -1),
     wxSize(-1, -1), wxTE_RIGHT);

  sizer->Add(display, 0, wxEXPAND | wxTOP | wxBOTTOM, 4);
  gs = new wxGridSizer(5, 4, 3, 3);

  gs->Add(new wxButton(this, 1050, wxT("Cls")), 0, wxEXPAND);
  gs->Add(new wxButton(this, -1, wxT("©")), 0, wxEXPAND);
  gs->Add(new wxStaticText(this, -1, wxT("")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 3000, wxT("Close")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1009, wxT("9")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1008, wxT("8")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1007, wxT("7")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2000, wxT("/")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1006, wxT("6")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1005, wxT("5")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1004, wxT("4")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2002, wxT("*")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1003, wxT("3")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1002, wxT("2")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1001, wxT("1")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2003, wxT("-")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1000, wxT("0")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2004, wxT("=")), 0, wxEXPAND);
  gs->Add(new wxStaticText(this, -1, wxT("")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2001 , wxT("+")), 0, wxEXPAND);

  sizer->Add(gs, 1, wxEXPAND);
  SetSizer(sizer);
  SetMinSize(wxSize(270, 220));

  Centre();
}

void GridSizer::onCls (wxCommandEvent& WXUNUSED (event)) {
  total = 0;
  cantidad1 = 0;
  cantidad2 = 0;
  identificador = 0;
  letras_total = "";
  numeroscontables1 = 0;
  numeroscontables2 = 0;
  lista1[100]={};
  lista2[500]={};
  display->Clear();
}

void GridSizer::onClose (wxCommandEvent& WXUNUSED (event)) {
  Destroy();
}

void GridSizer::onBt0 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("0");
  if(identificador == 0){
    lista1[numeroscontables1] = '0';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '0';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBt1 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("1");
  if(identificador == 0){
    lista1[numeroscontables1] = '1';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '1';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBt2 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("2");
  if(identificador == 0){
    lista1[numeroscontables1] = '2';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '2';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBt3 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("3");
  if(identificador == 0){
    lista1[numeroscontables1] = '3';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '3';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBt4 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("4");
  if(identificador == 0){
    lista1[numeroscontables1] = '4';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '4';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBt5 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("5");
  if(identificador == 0){
    lista1[numeroscontables1] = '5';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '5';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBt6 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("6");
  if(identificador == 0){
    lista1[numeroscontables1] = '6';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '6';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBt7 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("7");
  if(identificador == 0){
    lista1[numeroscontables1] = '7';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '7';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBt8 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("8");
  if(identificador == 0){
    lista1[numeroscontables1] = '8';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '8';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBt9 (wxCommandEvent& WXUNUSED (event)) {
  display->AppendText("9");
  if(identificador == 0){
    lista1[numeroscontables1] = '9';
    numeroscontables1 = numeroscontables1 + 1;
  }
  if(identificador != 0){
    lista2[numeroscontables2] = '9';
    numeroscontables2 = numeroscontables2 + 1;
  }
}

void GridSizer::onBtSum (wxCommandEvent& WXUNUSED (event)) {
	identificador = 1;
  display->AppendText(" + ");
}

void GridSizer::onBtRes (wxCommandEvent& WXUNUSED (event)) {
  identificador = 2;
  display->AppendText(" - ");
}

void GridSizer::onBtDiv (wxCommandEvent& WXUNUSED (event)) {
	identificador = 3;
  display->AppendText(" / ");
}

void GridSizer::onBtMul (wxCommandEvent& WXUNUSED (event)) {
	identificador = 4;
  display->AppendText(" x ");
}

void GridSizer::onBtIgual (wxCommandEvent& WXUNUSED (event)) {
    cantidad1 = atoi(lista1);
    cantidad2 = atoi(lista2);
    if (identificador == 1) {
      total = cantidad1 + cantidad2;
    }
    if (identificador == 2) {
      total = cantidad1 - cantidad2;
    }
    if (identificador == 3) {
      total = cantidad1 / cantidad2;
    }
    if (identificador == 4) {
      total = cantidad1 * cantidad2;
    }

    letras_total = to_string(total);
    display->AppendText(" = " + letras_total);

}

BEGIN_EVENT_TABLE(GridSizer, wxFrame)
    EVT_BUTTON(1050,  GridSizer::onCls)
    EVT_BUTTON(3000,  GridSizer::onClose)
    EVT_BUTTON(1000,  GridSizer::onBt0)
    EVT_BUTTON(1001,  GridSizer::onBt1)
    EVT_BUTTON(1002,  GridSizer::onBt2)
    EVT_BUTTON(1003,  GridSizer::onBt3)
    EVT_BUTTON(1004,  GridSizer::onBt4)
    EVT_BUTTON(1005,  GridSizer::onBt5)
    EVT_BUTTON(1006,  GridSizer::onBt6)
    EVT_BUTTON(1007,  GridSizer::onBt7)
    EVT_BUTTON(1008,  GridSizer::onBt8)
    EVT_BUTTON(1009,  GridSizer::onBt9)
    EVT_BUTTON(2001,  GridSizer::onBtSum)
    EVT_BUTTON(2003,  GridSizer::onBtRes)
    EVT_BUTTON(2002,  GridSizer::onBtMul)
    EVT_BUTTON(2000,  GridSizer::onBtDiv)
    EVT_BUTTON(2004,  GridSizer::onBtIgual)

END_EVENT_TABLE()
