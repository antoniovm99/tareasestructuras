#include"lista.cpp"
#include<iostream>
using namespace std;

int main(){
	int b;
	lista a;
	a.iniciar();
	a.insertar_lista(2);
	a.insertar_lista(3);
	a.insertar_lista(6);
	a.insertar_lista(8);
	a.mostrar();
	a.insertar_lista_posicion(5, 1);
	a.mostrar();
	for(int i = 0; i < a.longitud_lista(); i++){
		a.eliminar();
	}
}