#ifndef FUNCIONES_H
#define FUNCIONES_H

char matriz_juego[5][5];
char matriz_abc[5][5];

struct numeros_aleatorio{
  int numero;
  int numero2;
  int numero3;
  int numero4;
  int numero5;
  int numero6;
  int numero7;
  int numero8;
  int numero9;
  int numero10;
  int numero11;
  int numero12;
}aleatorio;

int buscarLetra(char letra , char abecedario[], int n);
void datosLeer();
char* leer (int movimiento , char abecedario[] , int n , int q);
char *obtenerCasilla(char letra);
void crear_matriz(char caracteres[],char abecedario[], int numero_abc, int q);
void imprimir_matriz(int q);
int cumplir_primera_condicion(char matriz_juego[5][5],char caracteres[],
  int i , int j ,int q);
int cumplir_segunda_condicion(char matriz_juego[5][5],char caracteres[],
  int i , int j, int q);
int cumplir_tercera_condicion(char matriz_juego[5][5],char caracteres[],
  int i , int j, int q);
int cumplir_cuarta_condicion(char matriz_juego[5][5],char caracteres[],
   int i , int j , int q);
void obtener_datos(int puntaje,int movimiento);
int verificarHorizontal (char matriz_juego[5][5],char *casilla2,char caracteres[],
  int i, int j, int q);
int verificarVertical(char matriz_juego[5][5],char *casilla2,char caracteres[],
 int i, int j, int q);
int verificarDiagonalIzquierda(char matriz_juego[5][5],char *casilla2,char caracteres[],
  int i, int j, int q);
int verificarDiagonalDerecha(char matriz_juego[5][5],char *casilla2,char caracteres[],
  int i, int j, int q);
void evaluarMatriz(char matriz_juego[5][5],char *casilla2,char caracteres[],
  int &puntaje, int i, int j,int movimiento, int q);

#endif
