#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include<time.h>

class Cadena{
  private:
    int size;
    int buffer;
  public:

}

void Cadena::concatenar(Cadena c2){
  char *s2 = c2.getbuffer();
  char *s1 = buffer;
  char *s3 = strcat(s1,s2);
  delete buffer;

  buffer = new char[c2.getlogitud()];
  strcpy(buffer,s3);
}

int Cadena::contarCaracter(char c){
  for (int i = 0; i < size; i++) {
    if (buffer[i] == c) {
      return i;
    }
  }
  return 1;
}

int main(){
  Cadena
}
