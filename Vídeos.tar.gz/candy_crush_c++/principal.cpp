#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include<time.h>
#include "funciones.h"

using namespace std;

int main() {

  cout << '\n'<< "**** CANDY CRUSH ****" << '\n'<<'\n';
  char caracteres[] = {'@','#','$','&','%'};
  char abecedario[]= {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o',
    'p','q','r','s','t','u','v','w','x','y'};
  int puntaje = 0,movimiento = 10, numero_abc = 0, i = 0, j = 0, n = 25, q = 5;

  crear_matriz(caracteres,abecedario,numero_abc, q);

  obtener_datos(puntaje,movimiento);

  while (movimiento >= 0) {
    char *casilla2 = leer(movimiento,abecedario,n,q);

    if(movimiento == 10){
      movimiento = movimiento - 1;
    }

    imprimir_matriz(q);

    evaluarMatriz(matriz_juego,casilla2,caracteres,puntaje, i, j,movimiento, q);

    obtener_datos(puntaje,movimiento);

    movimiento = movimiento - 1;

  }

  if (movimiento <= 0) {
    system("clear");
    cout << "EL JUEGO A TERMINADO";
    cout << '\n' << "Puntaje Total Obtenido: " << puntaje << endl;
  }
  return 0;
}
