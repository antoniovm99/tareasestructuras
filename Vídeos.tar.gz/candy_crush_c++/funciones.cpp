#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include<time.h>
#include <unistd.h>
#include "funciones.h"

// ********************************************************************************** //

/*
Precondicion: le entra como parametros, tipo char una letra, entrada por teclado
desde otra funcion, y la lista de tipo char, abecedario[].

PostCondicion: retorna si la letra se encuentra en la lista, la cual devuelve 1,
o devuelve 0, si no encuentra nada y no existe en nuestra lista de abecedario.
*/
int buscarLetra(char letra , char abecedario[], int n){
  for (int i = 0; i < n; i++) {
    if (abecedario[i] == letra) {
      return 1;
    }
  }
  return 0;
}

/*
PreCondicion: no tiene parametros ya que es una funcion tipo void.
PostCondicion: devuelve los datos de dormir pantalla, limpiar y mandar un mensaje
respectivo.
*/

void datosLeer(){
  cout << '\n'<< "Por favor, escriba una letra disponible en el tablero de juego" <<endl;
  sleep(3);
  system("clear");
}

/*
Precondicion: funcion que le entra como paramentro de tipo entero el numero de
movimientos, y que pide por teclado letra 1 y letra 2, la cual son de tipo char
y hace un swap mecanico, haciendo uso de la funcion obtenerCasilla(letra) para
conocer la posicion de la letra en nuestra matriz.

PostCondicion: retorna casilla2, y cambia las dos fichas que pedimos por entrada,
cambiando la posicion de cada uno.
*/
char* leer (int movimiento , char abecedario[] , int n , int q) {
  char letra1,letra2;
  cout << '\n' << "Cambiar letra: " << endl;
  cin >> letra1;
  char *casilla1 = obtenerCasilla(letra1);
  if(buscarLetra(letra1,abecedario,n) == 0){
    datosLeer();
    imprimir_matriz(q);
    return leer(movimiento,abecedario,n,q);
  }
  else{
    if (buscarLetra(letra1,abecedario,n) == 1) {
      cout << '\n' << "Por letra: " << endl;
      cin >> letra2;
      char *casilla2 = obtenerCasilla(letra2);
      if(buscarLetra(letra2,abecedario,n) == 0){
        datosLeer();
        imprimir_matriz(q);
        return leer(movimiento,abecedario,n,q);
      }
      else{
        if (buscarLetra(letra2,abecedario,n) == 1) {
          cout << *casilla1 << " , " << *casilla2 << endl;
          int tmp = *casilla1;
          *casilla1 = *casilla2;
          *casilla2 = tmp;
          cout << *casilla1 << " , " << *casilla2 << endl;
          system("clear");
          return casilla2;
        }
      }
    }
  }
}

/*
PreCondicion: le entra como parametro la letra obtenida por entrada, y recorre
la matriz para obtener la posicion de la letra dada.

PostCondicion: retorna la posicion de letra dada.
*/
char *obtenerCasilla(char letra){
  for (int i = 0; i < 5; i++)
    for (int j = 0; j < 5; j++)
      if (matriz_abc[i][j] == letra)
        return &matriz_juego[i][j];

  return NULL;
}

/*
PreCondicion: resive por parametros de tipo char, la lista: caracteres, la cuales son
las figuras del juego, el abecedario, el cual es la lista de todo las letras del
abecedario del juego, y de tipo entero, numero y numero_Abc para poder llevar un
contador y almacenar los numeros aleatorios.

PostCondicion: crea la matriz al comenzar el juego, usando de manera aleatoria
los caracteres a imprimir, mostrando, los caracteres aleatorios al lado de el abecedario.
*/
void crear_matriz(char caracteres[],char abecedario[], int numero_abc, int q){
  srand(time(NULL));
  for (int i = 0; i < q; i++) {
    for (int j = 0; j < q; j++) {
      aleatorio.numero = 0 + rand() % (q - 0);
      matriz_juego[i][j] = caracteres[aleatorio.numero];
      matriz_abc[i][j] = abecedario[numero_abc];
      printf(" %c (%c)",matriz_juego[i][j],matriz_abc[i][j]);
      numero_abc = numero_abc + 1;
    }
    printf("\n");
  }
}

/*
PreCondicion: es una funcion void, el cual no retorna nada, y no recibe nada por
parametros
PostCondicion: imprime la matriz utilizando los datos de las dos matrices, matriz_juego y
matriz_abc de lo almacenado en ellos anteriormente.
*/
void imprimir_matriz(int q){
  for (int i = 0; i < q; i++) {
    for (int j = 0; j < q; j++) {
      printf(" %c (%c)",matriz_juego[i][j],matriz_abc[i][j]);
    }
    printf("\n");
  }
}

/*
PreCondicion: recibe como parametros de tipo char, matriz_juego y caracteres,
y como de tipo entero, numero, numero2 y numero3 que son las variables
que contienen el aletorio de los numeros, en la posicion de la lista.
PostCondicion: cambia las tres letras de los caracteres donde hubo tripleta, crea
nuevos caracteres de manera  aletoria en dichas posiciones e imprimie la nueva matriz
haciendo uso del llamado de la funcion imprimir_matriz().
*/
int cumplir_primera_condicion(char matriz_juego[5][5],char caracteres[],
  int i , int j ,int q){
  srand(time(NULL));
  aleatorio.numero = 0 + rand() % (q - 0);
  aleatorio.numero2 = 0 + rand() % (q - 0);
  aleatorio.numero3 = 0 + rand() % (q - 0);
  matriz_juego[i][j] = caracteres[aleatorio.numero];
  matriz_juego[i][j-1] = caracteres[aleatorio.numero2];
  matriz_juego[i][j+1] = caracteres[aleatorio.numero3];

  system("clear");
  imprimir_matriz(q);
  return 0;
}

/*
PreCondicion: recibe como parametros de tipo char, matriz_juego y caracteres,
y como de tipo entero,numero4, numero5 y numero6 que son las variables
que contienen el aletorio de los numeros, en la posicion de la lista.
PostCondicion: cambia las tres letras de los caracteres donde hubo tripleta, crea
nuevos caracteres de manera  aletoria en dichas posiciones e imprimie la nueva matriz
haciendo uso del llamado de la funcion imprimir_matriz().
*/
int cumplir_segunda_condicion(char matriz_juego[5][5],char caracteres[],
  int i , int j, int q){
  srand(time(NULL));
  aleatorio.numero4 = 0 + rand() % (q - 0);
  aleatorio.numero5 = 0 + rand() % (q - 0);
  aleatorio.numero6 = 0 + rand() % (q - 0);
  matriz_juego[i][j] = caracteres[aleatorio.numero4];
  matriz_juego[i-1][j] = caracteres[aleatorio.numero5];
  matriz_juego[i+1][j] = caracteres[aleatorio.numero6];

  system("clear");
  imprimir_matriz(q);
  return 0;
}

/*
PreCondicion: recibe como parametros de tipo char, matriz_juego y caracteres,
y como de tipo entero, numero7, numero8 y numero9 que son las variables
que contienen el aletorio de los numeros, en la posicion de la lista.
PostCondicion: cambia las tres letras de los caracteres donde hubo tripleta, crea
nuevos caracteres de manera  aletoria en dichas posiciones e imprimie la nueva matriz
haciendo uso del llamado de la funcion imprimir_matriz().
*/
int cumplir_tercera_condicion(char matriz_juego[5][5],char caracteres[],
  int i , int j, int q){
  srand(time(NULL));
  aleatorio.numero7 = 0 + rand() % (q - 0);
  aleatorio.numero8 = 0 + rand() % (q - 0);
  aleatorio.numero9 = 0 + rand() % (q - 0);
  matriz_juego[i][j] = caracteres[aleatorio.numero7];
  matriz_juego[i-1][j-1] = caracteres[aleatorio.numero8];
  matriz_juego[i+1][j+1] = caracteres[aleatorio.numero9];

  system("clear");
  imprimir_matriz(q);
  return 0;
}

/*
PreCondicion: recibe como parametros de tipo char, matriz_juego y caracteres,
y como de tipo entero, numero10, numero11 y numero12 que son las variables
que contienen el aletorio de los numeros, en la posicion de la lista.
PostCondicion: cambia las tres letras de los caracteres donde hubo tripleta, crea
nuevos caracteres de manera  aletoria en dichas posiciones e imprimie la nueva matriz
haciendo uso del llamado de la funcion imprimir_matriz().
*/
int cumplir_cuarta_condicion(char matriz_juego[5][5],char caracteres[],
   int i , int j , int q){
  srand(time(NULL));
  aleatorio.numero10 = 0 + rand() % (q - 0);
  aleatorio.numero11 = 0 + rand() % (q - 0);
  aleatorio.numero12 = 0 + rand() % (q - 0);
  matriz_juego[i][j] = caracteres[aleatorio.numero10];
  matriz_juego[i-1][j+1] = caracteres[aleatorio.numero11];
  matriz_juego[i+1][j-1] = caracteres[aleatorio.numero12];

  system("clear");
  imprimir_matriz(q);
  return 0;
}

/*
PreCondicion: obtiene por parametros de tipo entero, el puntaje y movimientos a
llevar.
PostCondicion: imprime el puntaje obtenido que lleva hasta ahora y la cantidad
de movimientos que tiene disponible hasta ahora.
*/
void obtener_datos(int puntaje,int movimiento){
  cout << '\n' << "Puntaje Obtenido: " << puntaje << endl;
  cout << "Movimiento restantes: "<< movimiento << endl;
}

/*
PreCondicion: recibe por parametros de tipo char matriz_juego , *casilla2  y
caracteres, y de tipo entero puntaje, numero, numero2 y numero 3, la y el cual
busca verificar de manera horizontal si existe tripleta.
PostCondicion: verifica de manera horizontal si se encuentra una tripleta,
analizando la posicion de matriz_juego de cada ficha, contenida en casilla 2, si
se encuentra tripleta cumple la funcion cumplir_primera_condicion
y suma puntaje.
*/
int verificarHorizontal (char matriz_juego[5][5],char *casilla2,char caracteres[],
int i, int j, int q) {
  if ((matriz_juego[i][j] == *casilla2 && matriz_juego[i][j-1] == *casilla2
  &&  matriz_juego[i][j+1] == *casilla2)) {

    cumplir_primera_condicion(matriz_juego,caracteres,i,j,q);
    int d = cumplir_primera_condicion(matriz_juego,caracteres,i,j,q);
    return 1;
  }
  return 0;
}


/*
PreCondicion: recibe por parametros de tipo char matriz_juego , *casilla2  y
caracteres, y de tipo entero puntaje, numero4, numero5 y numero 6, la y el cual
busca verificar de manera vertical si existe tripleta.
PostCondicion: verifica de manera vertical si se encuentra una tripleta,
analizando la posicion de matriz_juego de cada ficha, contenida en casilla 2, si
se encuentra tripleta cumple la funcion cumplir_primera_condicion
y suma puntaje.
*/
int verificarVertical(char matriz_juego[5][5],char *casilla2,char caracteres[],
 int i, int j, int q) {

    if ((matriz_juego[i][j] == *casilla2 && matriz_juego[i-1][j] == *casilla2
    &&  matriz_juego[i+1][j] == *casilla2)) {

      cumplir_segunda_condicion(matriz_juego,caracteres,i,j,q);
      int w = cumplir_segunda_condicion(matriz_juego,caracteres,i,j,q);
      return 1;
    }
    return 0;
}


/*
PreCondicion: recibe por parametros de tipo char matriz_juego , *casilla2  y
caracteres, y de tipo entero puntaje, numero4, numero5 y numero 6, la y el cual
busca verificar de manera vertical si existe tripleta.
PostCondicion: verifica de manera diangonal izquierda si se encuentra una tripleta,
analizando la posicion de matriz_juego de cada ficha, contenida en casilla 2, si
se encuentra tripleta cumple la funcion cumplir_primera_condicion
y suma puntaje.
*/
int verificarDiagonalIzquierda(char matriz_juego[5][5],char *casilla2,char caracteres[],
int i, int j, int q) {

    if ((matriz_juego[i][j] == *casilla2 && matriz_juego[i-1][j-1] == *casilla2
    &&  matriz_juego[i+1][j+1] == *casilla2)) {

      cumplir_tercera_condicion(matriz_juego,caracteres,i,j,q);
      int e = cumplir_tercera_condicion(matriz_juego,caracteres,i,j,q);
      return 1;
    }
    return 0;
}


/*
PreCondicion: recibe por parametros de tipo char matriz_juego , *casilla2  y
caracteres, y de tipo entero puntaje, numero4, numero5 y numero 6, la y el cual
busca verificar de manera vertical si existe tripleta.
PostCondicion: verifica de manera Diagonal derecha si se encuentra una tripleta,
analizando la posicion de matriz_juego de cada ficha, contenida en casilla 2, si
se encuentra tripleta cumple la funcion cumplir_primera_condicion
y suma puntaje.
*/
int verificarDiagonalDerecha(char matriz_juego[5][5],char *casilla2,char caracteres[],
int i, int j, int q) {

    if ((matriz_juego[i][j] == *casilla2 && matriz_juego[i-1][j+1] == *casilla2
    &&  matriz_juego[i+1][j-1] == *casilla2)) {

      cumplir_cuarta_condicion(matriz_juego,caracteres,i,j,q);
      int f = cumplir_cuarta_condicion(matriz_juego,caracteres,i,j,q);
      return 1;
    }
    return 0;
}

/*
PreCondicion: recibe por parametros de tipo char matriz_juego , *casilla2  y
caracteres, y de tipo entero puntaje,numero, numero2, numero 3, numero4, numero5
 y numero 6, la y el cual verifica la matriz para poder obtener puntos y cambiarlos.
PostCondicion: verifica de manera vertical y horizontal si se encuentra una tripleta
haciendo uso de dos funcines verificarVertical y verificarHorizontal, recorriendo
la matriz y verificando, para poder sumar punto y cambiar los carateres.
*/

void evaluarMatriz(char matriz_juego[5][5],char *casilla2,char caracteres[],
int &puntaje, int i, int j,int movimiento, int q){
  for (int i = 0; i < q; i++) {
    for (int j = 0; j < q; j++) {
      int a = verificarHorizontal (matriz_juego,casilla2,caracteres,i, j, q);
      int b = verificarVertical (matriz_juego,casilla2,caracteres,i, j, q);
      int c = verificarDiagonalIzquierda (matriz_juego,casilla2,caracteres,i, j, q);
      int d = verificarDiagonalDerecha (matriz_juego,casilla2,caracteres,i, j, q);
      if(a == 1 || b == 1 || c == 1 || d == 1){
        puntaje = puntaje + 1;
      }
    }
  }
}
