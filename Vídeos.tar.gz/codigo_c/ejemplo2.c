#include <stdio.h>
#include <string.h>

int main(int argc, char const *argv[]) {

  string codigo
  codigo = ("probando probando uno dos tres \n");

  printf("el codigo actual dice: %d\n",codigo );

  return 0;
}
