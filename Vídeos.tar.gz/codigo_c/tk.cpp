#include <iostream> // biblioteca que contiene las funciones de entrada y salida de c++ . Viene Input/Output Stream
#include <cstdlib>
using namespace std;
int main()
{
    cout << "¡Hola, mundo!" << endl;
    system("pause");
    return 0;
}
