#include <stdio.h> // stdio: entrada/salida (printf,scanf,puts,gets)

int main() {

  int numero1 ;
  char cara;
  char nombre[] = "Esto imprime una cadena";
  numero1 = 2017;
  cara = '@';
  int arreglo[5]; // forma 1 para asignar un arreglo
  int arreglo1[]= {1,2,3,4,5}; // forma 2 para hacer un arreglo 

  arreglo[0] = 8; // especificamos la posicion de cada arreglo
  arreglo[1] = 10; //
  arreglo[2] = 15; //
  arreglo[3] = 24; //
  arreglo[4] = 2323; //

  printf( "Texto: %s\n", nombre );
  printf("El numero uno vale: %d\n",numero1 );
  printf("Esto imprime el caracter: %c\n",cara );
  printf("Esto imprime cuanto vale: %d\n",cara);
  for (int i = 0; i <= 5; i++) {
    printf("%d\n",arreglo[i] );
  }
  for (int i = 0; i < 5; i++) {
    printf("%d\n",arreglo1[i] );
  }
  return 0;

}
