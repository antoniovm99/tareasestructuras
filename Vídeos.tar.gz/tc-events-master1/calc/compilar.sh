g++ main.cpp gridsizer.cpp  `wx-config --cxxflags --libs std` -o calc.exe
