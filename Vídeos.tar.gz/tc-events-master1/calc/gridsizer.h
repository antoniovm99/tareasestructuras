#include <wx/wx.h>
#include <iostream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

class GridSizer : public wxFrame
{
private:
  int valor1;
  int valor2;
  int resultado;
  int operacion;
  int contador1 = 0;
  int contador2 = 0;
  char numero1[100];
  char numero2[100];
  DECLARE_EVENT_TABLE()

public:
  GridSizer(const wxString& title);

  wxBoxSizer *sizer;
  wxGridSizer *gs;
  wxTextCtrl *display;

  void onCls (wxCommandEvent&);
  void onBt1 (wxCommandEvent&);
  void onBt2 (wxCommandEvent&);
  void onBt3 (wxCommandEvent&);
  void onBt4 (wxCommandEvent&);
  void onBt5 (wxCommandEvent&);
  void onBt6 (wxCommandEvent&);
  void onBt7 (wxCommandEvent&);
  void onBt8 (wxCommandEvent&);
  void onBt9 (wxCommandEvent&);
  void onBtSum (wxCommandEvent&);
  void onBt_restar (wxCommandEvent&);
  void onBt_multi (wxCommandEvent&);
  void onBt_div (wxCommandEvent&);
  void onBt_igual (wxCommandEvent&);
};
