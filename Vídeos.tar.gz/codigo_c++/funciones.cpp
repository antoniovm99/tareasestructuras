// como se implenta 

#include <iostream>
#include <math.h>

int calpotencia (int b, int e) {
  int res = pow(b,e);
  return res;
}

float calcoseno(float v){

  int res = cos(v);
  return res;
}
