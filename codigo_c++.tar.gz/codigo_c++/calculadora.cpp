// Ejemplo de uso de la librerias iostream y math
#include <iostream>  // cin, cout
#include <math.h>    // pow

using namespace std; // strings

int main () {
	//int valorBase;
	//int valorExponente;
  int seleccion;
  int numero1;
  int numero2;
  int valortotal;

	// Lee desde el teclado
	//cout << "Ingrese valor para la base: "  ;
  //cin >>  valorBase;

	//cout << "Ingrese valor para el exponente: " ;
	//cin >>  valorExponente;

  //int valorPotencia = pow (valorBase, valorExponente);
	//cout << "La potencia es: " << valorPotencia << endl;

  cout << "CALCULADORA HD" << '\n';
  std::cout << "" << '\n';

  cout << "Operacion a realizar: " << '\n';
  cout << "" << '\n';

  cout << "1) SUMA." << '\n';
  cout << "2) RESTA." << '\n';
  cout << "3) MULTIPLICACION." << '\n';
  cout << "4) DIVISION." << '\n';
  cout << "5) POTENCIA." << '\n';
  cout << "6) COSENO." << '\n';
  cout << "7) SENO." << '\n';
  cout << "8) RAIZ CUADRADA." << '\n';
  cout << "9) TANGENTE." << '\n';
 // cin, cout
  cout << "Digite Primer Numero: " << '\n';
  cin >>  numero1;
  cout << "Digite Segundo Numero: " << '\n';
  cin >> numero2;
  cout << "Digite Operacion a Realizar: " << '\n';
  cin >> seleccion;

  switch (seleccion) {
    case 1:
      valortotal = numero1 + numero2;
      cout << "EL resultado de la suma es: " << valortotal << endl;
      break;

    case 2:
      valortotal = numero1 - numero2;
      cout << "EL resultado de la resta es: " << valortotal << endl;
      break;

    case 3:
      valortotal = numero1 * numero2;
      cout << "EL resultado de la multiplicacion es: " << valortotal << endl;
      break;

    case 4:
      valortotal = numero1 / numero2;
      cout << "El resultado de la division es: " << valortotal << endl;
      break;

    case 5:
      valortotal = pow(numero1,numero2);
      cout << "El resultado de la pontencia es: " << valortotal << endl;
      break;

    case 6:
      valortotal = cos(numero1);
      cout << "El resultado del coseno es: " << valortotal << endl;
      break;

    case 7:
      valortotal = sin(numero1);
      cout << "El resultado del seno es: " << valortotal << endl;
      break;

    case 8:
      if (numero1 >= 0) {
        valortotal = sqrt(numero1);
        cout << "El resultdo de la raiz es: " << valortotal << endl;
      }
      else{
        cout << "Raiz cuadrada de valores negativos NO EXISTE." << '\n';
      }
      break;

    case 9:
      valortotal = tan(numero1);
      cout << "El resultado de la tangente es: " << valortotal << endl;
      break;

    default:
      cout << "No se encuentra en el rango de opciones, intentalo de nuevo" << '\n';
      break;
    }

    return 0;
}
