#include <stdio.h>
#include <iostream>
#include <stdlib.h>

using namespace std;


int funcion_binaria(char A[],int ini, int fin){

  if(fin == ini){
    if(A[ini] == '0'){
      return 1;
    }
    else{
      return 0;
    }
  }

  else{

    int mitad = (ini+fin)/2;
    int lado_izquierdo=funcion_binaria(A,ini,mitad);
    int lado_derecho=funcion_binaria(A,mitad+1,fin);

    return lado_derecho + lado_izquierdo;

  }

}

void imprimir_arreglo(char* arr,int n) {
  for (int i = 0; i < n; i++) {
    cout<<" "<<arr[i];
  }
}

int main() {
  char A[] = {'1','0','0','1','1','0'};
  int B = funcion_binaria(A,0,6);
  cout<<B<<endl;
  return 0;
}
