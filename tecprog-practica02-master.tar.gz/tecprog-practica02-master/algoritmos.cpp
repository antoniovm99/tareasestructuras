#include <math.h>

int potencia (int base, int exponente) {
	int resultado;
	resultado = pow (base, exponente);
	return resultado;
}

