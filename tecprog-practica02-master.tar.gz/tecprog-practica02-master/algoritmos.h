#ifndef __ALGORITMOS_H__
#define  __ALGORITMOS_H__

int potencia (int base, int exponente);

#endif
