# tecprog-practica02
Algoritmos Fuerza Bruta en C++
