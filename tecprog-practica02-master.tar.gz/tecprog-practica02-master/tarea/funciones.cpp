#include <iostream>
#include <math.h>

//*******************************************//

int buscar (int v[] , int x ){

  int k;
  int sw = 0;


  for (k = 0 ; k < 5 ; k++) {

    if (x == v[k]) {
      sw = 1;
      return k;
    }

  }

  if (sw == 0){

    return (-1);
  }

}


//*************************************************//

void potenciatotal  (int base , int exponente){

  long p = 1;

  for (int i = 1; i <= exponente; i++){
    p = p * base;
  }

  std::cout << "LA PONTENCIA ES: " << p;
  std::cout << "" << '\n';
  //return p;
}

//**********************************************//

void ordenar (int v[]){

  int i,j,aux;

  for ( i = 0; i < 5; i++) {
    for (j = i+1 ; j < 5 ; j++) {
      if (v[j] < v[i]) {
        aux = v[i];
        v[i] = v[j];
        v[j] = aux;
      }
    }
  }

  for ( i = 0; i < 5; i++) {
    std::cout << " " << v[i];
  }

}

//******************************************//

void ordenar2 (int v[]){

  int min = 9999;

  for ( int k  = 0; k < 5; k++) {
    for (int i = k; i < 5; i++) {
      if (v[i] < min) {
        min = v[i];

      }
  }

  v[k] = min;

  }


  for ( i = 0; i < 5; i++) {
    cout << " " << v[i];
  }

}

//*************************************************//


int emparejamiento(char v1[],char v2[]) {


  int c,i,k,j = 0;
  int sw = 0;

  for ( i = 0; i < 15; i++) {

    c = i;

    for (k = 0; k < 4; k++) {

      if (v2[k] == v1[c]) {
        j++;
      }

    c++;

    }

    if (j == 5) {

      sw = 1;
      return i;
    }
  }

  if (sw == 0) {
    std::cout << "NO EMPAREJADOS" << '\n';
    return (-1);
  }

}
