
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

int main()
{
	int n1,n2,i=0,j=0,x,y;

  char  matriz[5][5];

	for (i=0;i<5;i++)
	{
		for (j=0;j<5;j++)
		{
      matriz[i][j] = 0;
			printf(" %d ",matriz[i][j]);
		}
	printf("\n");
	}

	return 0;
}
