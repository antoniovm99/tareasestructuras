#include <iostream>
#include <stdio.h>
#include <string.h>


using namespace std;

int main() {


  char cadena[] = {"HolaMundo"};
  int largo = strlen (cadena);
  for (int i = largo;  i >= 0; i--) {
    std::cout << "" << cadena[i];
  }
  return 0;
}
