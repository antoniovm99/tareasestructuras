#include <iostream>


int emparejamiento(char v1[],char v2[]) {


  int c,i,k,j = 0;
  int sw = 0;

  for ( i = 0; i < 15; i++) {

    c = i;

    for (k = 0; k < 4; k++) {

      if (v2[k] == v1[c]) {
        j++;
      }

    c++;

    }

    if (j == 5) {

      sw = 1;
      return i;
    }
  }

  if (sw == 0) {
    return (-1);
  }

}


int main() {

  char v1[] = {'h','o','l','a','c','o','m','o','e','s','t','a','s','h','o','y'};
  char v2[] = {'e','s','h','o'};
  int op;
  //  ordenar(v);
  //ordenar2(v);
  op = emparejamiento(v1,v2);
  if (op == -1) {
    std::cout << "NO EMPAREJADOS" << '\n';
  }
  else
    std::cout << "EMPAREJADOS" << '\n';
  return 0;
}
