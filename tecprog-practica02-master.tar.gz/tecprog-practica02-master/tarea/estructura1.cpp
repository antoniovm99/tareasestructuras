#include <iostream>
#include <conio.h>


using namespace std;


struct cliente{
  char nombre[30];
  int edad;
  int telefono;
};

struct datos_almacen{
  char camisa[30];
  struct cliente detalles_cliente;
  int precio;
}
clientes[2];


int main() {

  for (int i = 0; i < 2 ; i++) {
    cout << "nombre de la camisa: ";
    cin.getline(clientes[i].camisa,30);
    cout << "nombre del cliente ";
    cin.getline(clientes[i].detalles_cliente.nombre,[30]);
  }

  for (int i = 0; i < 2; i++) {
    cout << "" << (clientes[i].detalles_cliente.nombre);
  }

  return 0;
}
