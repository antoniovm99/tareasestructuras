#include <iostream>
#include <stdio.h>
#include <string.h>

int main() {

  char cadena[5];

  for (int i = 0; i < 5; i++) {
    cadena[i] = '0';
  }

  for (int i = 0; i < 5; i++) {
    std::cout << "" << cadena[i];
  }
  return 0;
}
