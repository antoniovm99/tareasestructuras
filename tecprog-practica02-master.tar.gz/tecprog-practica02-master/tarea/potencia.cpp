////

#include <iostream>
#include <math.h>

//******************************************************************//

void potenciatotal  (int base , int exponente){

  long p = 1;

  for (int i = 1; i <= exponente; i++){
    p = p * base;
  }

  std::cout << "LA PONTENCIA ES: " << p;
  std::cout << "" << '\n';
  //return p;
}

//*************************************************************//

int main (){

  int b,e;
  long r;

  std::cout << "Digite la base:" << '\n';
  std::cin >> b;

  std::cout << "Digite el exponente:" << '\n';
  std::cin >> e;

  if (b == 0 && e == 0) {
    std::cout << "LA PONTENCIA NO EXISTE!!" << '\n';
  }

  else
    if (b == 0) {
      std::cout << "LA PONTECIA EN CEROOO!!" << '\n';
    }
    else
      if (b == 1 || e == 0) {
        std::cout << "LA PONTECIA ES UNO!!" << '\n';
      }
      else{
        potenciatotal(b,e);
        //std::cout << "LA PONTENCIA ES: " << r;
        //std::cout << "" << '\n';
      }

  return 0;
}
