//**************************************//

#include <iostream>

//***************************************//

int buscar (int v[] , int x ){

  int k;
  int sw = 0;


  for (k = 0 ; k < 5 ; k++) {

    if (x == v[k]) {
      sw = 1;
      return k;
    }

  }

  if (sw == 0){

    return (-1);
  }

}

//***************************************//

int main() {

  int vector[5];
  int contador;
  int numero,num_usuario;
  int op;

  for (contador = 0; contador < 5; contador++) {
    std::cout << "Digite numero: " << '\n';
    std::cin >> num_usuario;
    vector[contador] = num_usuario;
  }

  std::cout << "Digite numero a buscar: " << '\n';
  std::cin >> numero;

  op =  buscar(vector,numero);
  if (op == -1) {
    std::cout << "EL NUMERO DIGITADO NO SE ENCUENTRA DENTRO DEL VECTOR." << '\n';
    std::cout << "" << '\n';
  }
  else
   std::cout << "EL NUMERO SE ENCUENTRA EN LA POSCION: " << op;
   std::cout << "" << '\n';

  return 0;
}
