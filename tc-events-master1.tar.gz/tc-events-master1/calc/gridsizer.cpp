#include "gridsizer.h"
#include <iostream>
using namespace std;

GridSizer::GridSizer(const wxString& title)
       : wxFrame(NULL, -1, title, wxPoint(-1, -1), wxSize(270, 220))
{
  sizer = new wxBoxSizer(wxVERTICAL);

  display = new wxTextCtrl(this, -1, wxT(""), wxPoint(-1, -1),
     wxSize(-1, -1), wxTE_RIGHT);

  sizer->Add(display, 0, wxEXPAND | wxTOP | wxBOTTOM, 4);
  gs = new wxGridSizer(5, 4, 3, 3);

  gs->Add(new wxButton(this, 1050, wxT("Cls")), 0, wxEXPAND);
  gs->Add(new wxButton(this, -1, wxT("X")), 0, wxEXPAND);
  gs->Add(new wxStaticText(this, -1, wxT("")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 3000, wxT("Close")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1009, wxT("9")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1008, wxT("8")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1007, wxT("7")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2000, wxT("/")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1006, wxT("6")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1005, wxT("5")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1004, wxT("4")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2002, wxT("*")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1003, wxT("3")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1002, wxT("2")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1001, wxT("1")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2003, wxT("-")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 1000, wxT("0")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2004, wxT("=")), 0, wxEXPAND);
  gs->Add(new wxStaticText(this, -1, wxT("")), 0, wxEXPAND);
  gs->Add(new wxButton(this, 2001 , wxT("+")), 0, wxEXPAND);

  sizer->Add(gs, 1, wxEXPAND);
  SetSizer(sizer);
  SetMinSize(wxSize(270, 220));

  Centre();
}

void GridSizer::onCls (wxCommandEvent& WXUNUSED (event)) {
	display ->Clear();
	contador1 = 0;
	contador2 = 0;
	valor1 = 0;
	valor2 = 0;
	resultado = 0;
	operacion = 0;
	numero1[100] = {};
    numero2[100] = {};
}


void GridSizer::onBt1 (wxCommandEvent& WXUNUSED (event)) {
	display->AppendText("1");
	if(operacion == 0){
		numero1[contador1] = '1';
		contador1 = contador1 + 1;
	}
	else{
		numero2[contador2] = '1';
		contador2 = contador2 + 1;
	}
}

void GridSizer::onBt2 (wxCommandEvent& WXUNUSED (event)) {
	display->AppendText("2");
	if(operacion == 0){
		numero1[contador1] = '2';
		contador1 = contador1 + 1;
	}
	else{
		numero2[contador2] = '2';
		contador2 = contador2 + 1;
	}
}

void GridSizer::onBt3 (wxCommandEvent& WXUNUSED (event)) {
	display->AppendText("3");
	if(operacion == 0){
		numero1[contador1] = '3';
		contador1 = contador1 + 1;
	}
	else{
		numero2[contador2] = '3';
		contador2 = contador2 + 1;
	}
}

void GridSizer::onBt4 (wxCommandEvent& WXUNUSED (event)) {
	display->AppendText("4");
	if(operacion == 0){
		numero1[contador1] = '4';
		contador1 = contador1 + 1;
	}
	else{
		numero2[contador2] = '4';
		contador2 = contador2 + 1;
	}
}

void GridSizer::onBt5 (wxCommandEvent& WXUNUSED (event)) {
	display->AppendText("5");
	if(operacion == 0){
		numero1[contador1] = '5';
		contador1 = contador1 + 1;
	}
	else{
		numero2[contador2] = '5';
		contador2 = contador2 + 1;
	}
}

void GridSizer::onBt6 (wxCommandEvent& WXUNUSED (event)) {
	display->AppendText("6");
	if(operacion == 0){
		numero1[contador1] = '6';
		contador1 = contador1 + 1;
	}
	else{
		numero2[contador2] = '6';
		contador2 = contador2 + 1;
	}
}

void GridSizer::onBt7 (wxCommandEvent& WXUNUSED (event)) {
	display->AppendText("7");
	if(operacion == 0){
		numero1[contador1] = '7';
		contador1 = contador1 + 1;
	}
	else{
		numero2[contador2] = '7';
		contador2 = contador2 + 1;
	}
}

void GridSizer::onBt8 (wxCommandEvent& WXUNUSED (event)) {
	display->AppendText("8");
	if(operacion == 0){
		numero1[contador1] = '8';
		contador1 = contador1 + 1;
	}
	else{
		numero2[contador2] = '8';
		contador2 = contador2 + 1;
	}
}

void GridSizer::onBt9 (wxCommandEvent& WXUNUSED (event)) {
	display->AppendText("9");
	if(operacion == 0){
		numero1[contador1] = '9';
		contador1 = contador1 + 1;
	}
	else{
		numero2[contador2] = '9';
		contador2 = contador2 + 1;
	}

}

void GridSizer::onBtSum (wxCommandEvent& WXUNUSED (event)){
	int total = valor1 + valor2;
	cout << "Resultado suma " << total << endl;
}


BEGIN_EVENT_TABLE(GridSizer, wxFrame)
    EVT_BUTTON(1050,  GridSizer::onCls)
    EVT_BUTTON(1001,  GridSizer::onBt1)
    EVT_BUTTON(1002,  GridSizer::onBt2)
    EVT_BUTTON(1003,  GridSizer::onBt3)
    EVT_BUTTON(1004,  GridSizer::onBt4)
    EVT_BUTTON(1005,  GridSizer::onBt5)
    EVT_BUTTON(1006,  GridSizer::onBt6)
    EVT_BUTTON(1007,  GridSizer::onBt7)
    EVT_BUTTON(1008,  GridSizer::onBt8)
    EVT_BUTTON(1009,  GridSizer::onBt9)
    EVT_BUTTON(2001,  GridSizer::onBtSum)
END_EVENT_TABLE()
