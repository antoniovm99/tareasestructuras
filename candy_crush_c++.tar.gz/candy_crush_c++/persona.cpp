#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <time.h>
#include <unistd.h>
#include "persona.h"

using namespace std;

Persona :: Persona(){
  nombre = "Antonio";
  edad = 18;
}

Persona :: Persona(string n_nombre,int n_edad){
  nombre = n_nombre;
  edad = n_edad;
}

void Persona :: caminar(){
  cout << "holaaa estoy caminando."<< endl;
}

void Persona :: presentarse(){
  cout << "Yo soy " << nombre << endl;
  cout << "Y tengo la edad: " << edad << endl;
}
