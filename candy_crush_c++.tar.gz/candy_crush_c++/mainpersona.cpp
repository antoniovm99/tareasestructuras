#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <time.h>
#include <unistd.h>
#include "persona.h"

int main() {
  Persona p1;
  p1.presentarse();
  Persona p2("Maria",20);
  p2.presentarse();
  return 0;
}
