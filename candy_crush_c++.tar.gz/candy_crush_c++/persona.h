#ifndef _PERSONA_H_
#define _PERSONA_H_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <time.h>
#include <unistd.h>

using namespace std;

class Persona{
protected:
  string nombre;
  int edad;

public:
  Persona();
  Persona(string n_nombre,int n_edad);
  void caminar();
  void presentarse();
};

#endif
